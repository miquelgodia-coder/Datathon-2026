"""
agent.py
Plantilla oficial de l'agent de control per al repte de la bateria de UPC Sostenible.
Datathon 2026.
"""


class BatteryAgent:

    def __init__(self):
        self.llindar_preu_carrega = 0.08
        self.llindar_preu_descarrega = 0.16
        self.potencia_nominal_kw = 500.0

        self.capacitat = 2000.0
        self.rendiment_eta = 0.9487

        self.soc_minim = 0.10
        self.soc_maxim = 0.98

        # Historial senzill per recordar el consum net habitual de cada hora
        self.historial = {}

    def act(self, obs):

        hora = obs["hour"]
        preu = obs["preu_actual"]
        soc = obs["soc_pct"]
        soc_kwh = obs["soc_kwh"]
        co2 = obs["co2_actual"]

        preus_properes_24h = obs["preus_properes_24h"]
        co2_properes_24h = obs["co2_properes_24h"]

        noves_dades_5min = obs["noves_dades_5min"]
        ultim_consum_kw = noves_dades_5min["ultim_consum_kw"]
        ultima_solar_kw = noves_dades_5min["ultima_solar_kw"]

        # Guardem la dada de consum net de l'hora anterior per tenir referència
        hora_anterior = (hora - 1) % 24
        consum_net_anterior = ultim_consum_kw - ultima_solar_kw
        if hora_anterior not in self.historial:
            self.historial[hora_anterior] = []
        self.historial[hora_anterior].append(consum_net_anterior)
        if len(self.historial[hora_anterior]) > 14:
            self.historial[hora_anterior].pop(0)

        n = min(len(preus_properes_24h), len(co2_properes_24h))

        if n == 0:
            return 0.0

        preus = list(preus_properes_24h[:n])
        emissions = list(co2_properes_24h[:n])

        preu_minim = min(preus)
        preu_maxim = max(preus)
        co2_minim = min(emissions)
        co2_maxim = max(emissions)

        puntuacions = []

        for i in range(n):

            if preu_maxim == preu_minim:
                preu_normalitzat = 0.5
            else:
                preu_normalitzat = (preus[i] - preu_minim) / (preu_maxim - preu_minim)

            if co2_maxim == co2_minim:
                co2_normalitzat = 0.5
            else:
                co2_normalitzat = (emissions[i] - co2_minim) / (co2_maxim - co2_minim)

            puntuacio = 0.7 * co2_normalitzat + 0.3 * preu_normalitzat
            puntuacions.append(puntuacio)

        puntuacio_actual = puntuacions[0]
        puntuacions_ordenades = sorted(puntuacions)

        # Seleccionem només les millors hores (15% més baix i 15% més alt)
        puntuacio_baixa = puntuacions_ordenades[int((n - 1) * 0.15)]
        puntuacio_alta = puntuacions_ordenades[int((n - 1) * 0.85)]

        # Comprovem si el guany del dia compensa les pèrdues de la bateria (~10%)
        marge_rendiment = (preu_maxim * (self.rendiment_eta ** 2)) > (preu_minim * 1.05)
        marge_co2 = (co2_maxim * (self.rendiment_eta ** 2)) > (co2_minim * 1.05)
        cicle_rendible = marge_rendiment or marge_co2

        consigna = 0.0

        excedent_solar = max(0.0, ultima_solar_kw - ultim_consum_kw)
        consum_net = max(0.0, ultim_consum_kw - ultima_solar_kw)

        # Estimem el consum d'aquesta hora amb l'historial si en tenim
        if hora in self.historial and len(self.historial[hora]) > 0:
            consum_estimat = sum(self.historial[hora]) / len(self.historial[hora])
            if consum_estimat > 0:
                consum_net = max(consum_net, consum_estimat * 0.85)

        # 1. Prioritat absoluta: aprofitar excedent solar gratuït i sense emissions
        if excedent_solar > 0 and soc < self.soc_maxim:
            consigna = min(self.potencia_nominal_kw, excedent_solar)

        # 2. Carregar de la xarxa només si és hora molt barata/neta i el cicle surt a compte
        elif puntuacio_actual <= puntuacio_baixa and soc < 0.85 and cicle_rendible:
            # Deixem un 15% lliure (fins a 0.85) per si al migdia hi ha excedent solar
            if 10 <= hora <= 15:
                consigna = self.potencia_nominal_kw
            else:
                consigna = self.potencia_nominal_kw * 0.8

        # 3. Descarregar en hores punta per evitar preus alts i emissions
        elif puntuacio_actual >= puntuacio_alta and soc > self.soc_minim and cicle_rendible:
            consigna = -self.potencia_nominal_kw

        # Límits físics de seguretat de la bateria
        max_carrega = min(self.potencia_nominal_kw,max(0.0, (self.capacitat * self.soc_maxim - soc_kwh) / self.rendiment_eta))

        max_descarrega = min(self.potencia_nominal_kw,max(0.0, (soc_kwh - self.capacitat * self.soc_minim) * self.rendiment_eta),consum_net)

        consigna = max(-max_descarrega, min(max_carrega, consigna))

        return float(consigna)
